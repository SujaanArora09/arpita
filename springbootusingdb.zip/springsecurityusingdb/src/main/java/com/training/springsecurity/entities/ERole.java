package com.training.springsecurity.entities;

public enum ERole {
	ROLE_USER, ROLE_CHILD, ROLE_ADMIN, ROLE_PARENT
}