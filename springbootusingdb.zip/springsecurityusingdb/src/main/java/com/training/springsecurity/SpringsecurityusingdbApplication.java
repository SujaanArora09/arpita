package com.training.springsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringsecurityusingdbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringsecurityusingdbApplication.class, args);
	}

}
