package com.training.springsecurity.security.payload.response;



public class MessageResponse {
	private String message;

	public MessageResponse() {
		// TODO Auto-generated constructor stub
	}

	public MessageResponse(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	

}