package com.training.springsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringsecurityusingdbApplicationTests {

	@Test
	void contextLoads() {
	}

}
